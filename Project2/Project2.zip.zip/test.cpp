#include "Map.h"
#include <iostream>
#include <cassert>
using namespace std;

void test()
{
	Map m;
	assert(m.insert(10, "diez"));
	assert(m.insert(20, "veinte"));
	assert(m.size() == 2);
	ValueType v = "cuarenta y dos";
	assert(!m.get(30, v) && v == "cuarenta y dos");
	assert(m.get(10, v) && v == "diez");
	v = "cuarenta y dos";
	KeyType x = 30;
	assert(m.get(0, x, v) &&
		((x == 10 && v == "diez") || (x == 20 && v == "veinte")));
	KeyType x2 = 40;
	assert(m.get(1, x2, v) &&
		((x2 == 10 && v == "diez") || (x2 == 20 && v == "veinte")) &&
		x != x2);
}

int main()
{
	test();
	cout << "Passed all tests" << endl;
}


/*#include "Map.h"

#include <iostream>
#include <string>
#include <cassert>

using namespace std;

bool combine(const Map& m1, const Map& m2, Map& result);

int main()
{
	KeyType key;
	ValueType value;
	Map a;
	assert(a.size() == 0);
	assert(a.empty());
	assert(!a.get("Annie", value));
	assert(!a.get(1, key, value));
	assert(!a.contains("Annie"));
	assert(a.insert("Annie", 1));
	assert(a.get("Annie", value) && value == 1);
	assert(a.get(0, key, value) && key == "Annie" && value == 1);
	assert(a.size() == 1);
	assert(!a.contains("Bonnie"));
	assert(!a.empty());
	assert(!a.insert("Annie", 3));
	assert(!a.insert("Annie", 1));
	assert(a.update("Annie", 25));
	assert(!a.get(1, key, value));
	assert(!a.get("Bonnie", value));
	assert(a.insertOrUpdate("Bonnie", 22));
	assert(a.get("Bonnie", value) && value == 22);
	assert(a.get(1, key, value) && key == "Bonnie" && value == 22);
	assert(!a.update("Tony", 0));
	assert(a.size() == 2);
	assert(a.contains("Annie"));
	assert(a.contains("Bonnie"));
	assert(!a.contains("Tony"));
	assert(a.size() == 2);
	Map parents;
	assert(parents.size() == 0);
	assert(parents.empty());
	assert(!parents.update("Sunny", 55));
	assert(parents.insertOrUpdate("Sunny", 53));
	assert(!parents.update("Tony", 54));
	assert(parents.update("Sunny", 55));
	assert(parents.insertOrUpdate("Tony", 54));
	Map b(a);
	assert(b.size() == 2);
	assert(!b.empty());
	assert(b.insertOrUpdate("Annie", 35));
	assert(!b.insert("Annie", 98));
	assert(b.update("Bonnie", 18));
	assert(b.insert("Conny", 13));
	assert(b.get("Conny", value) && value == 13);
	assert(b.size() == 3);
	assert(!b.empty());
	Map c = a;
	assert(c.size() == 2);
	assert(!c.empty());
	assert(!c.contains("Conny"));
	assert(!c.insert("Annie", 12));
	assert(!c.insert("Bonnie", 12));
	assert(!c.update("Conny", 12));
	assert(c.insertOrUpdate("Bonnie", 19));
	assert(c.size() == 2);
	assert(c.insertOrUpdate("Tony", 54));
	assert(c.insertOrUpdate("Sunny", 55));
	assert(c.size() == 4);
	assert(!c.empty());
	Map empty;
	assert(empty.empty());
	assert(empty.size() == 0);
	Map emptyCopy(empty);
	assert(emptyCopy.empty());
	assert(emptyCopy.size() == 0);
	emptyCopy.insertOrUpdate("Sara", 18);
	assert(!emptyCopy.empty());
	assert(emptyCopy.size() == 1);
	emptyCopy = empty;
	assert(emptyCopy.empty());
	assert(emptyCopy.size() == 0);
	assert(!emptyCopy.contains("Sara"));
	Map single;
	assert(single.empty());
	assert(single.insert("andreadytomingle", 1));
	Map anotherSingle(single);
	assert(anotherSingle.contains("andreadytomingle"));
	assert(anotherSingle.size() == 1);
	assert(anotherSingle.insertOrUpdate("blind date", 0));
	assert(anotherSingle.size() == 2);
	anotherSingle = single;
	assert(!anotherSingle.empty());
	assert(anotherSingle.size() == 1);
	assert(anotherSingle.contains("andreadytomingle"));
	assert(!anotherSingle.contains("blind date"));
	assert(!anotherSingle.erase("blind date"));
	assert(anotherSingle.erase("andreadytomingle"));
	assert(anotherSingle.empty());
	assert(anotherSingle.size() == 0);
	assert(!empty.erase("clap"));
	assert(c.insert("Conny", 5));
	assert(c.size() == 5);
	assert(c.erase("Conny"));
	assert(c.erase("Bonnie"));
	assert(!c.get("Bonnie", value));
	assert(!c.get(3, key, value));
	assert(c.size() == 3);
	swap(c, parents);
	assert(parents.size() == 3 && c.size() == 2);
	assert(c.get("Sunny", value) && value == 55);
	assert(c.get(0, key, value) && key == "Sunny" && value == 55);
	assert(c.get(c.size() - 1, key, value) && key == "Tony" && value == 54);
	assert(parents.get(0, key, value) && key == "Annie" && value == 25);
	assert(parents.get(parents.size() - 1, key, value) && key == "Sunny" && value == 55);
	assert(parents.get(parents.size() - 2, key, value) && key == "Tony" && value == 54);
	Map m1, m2;
	m1.insertOrUpdate("Fred", 123);
	m1.insertOrUpdate("Ethel", 456);
	m1.insertOrUpdate("Lucy", 789);
	m2.insertOrUpdate("Lucy", 789);
	m2.insertOrUpdate("Ricky", 321);
	assert(combine(m1, m2, empty));
	assert(empty.size() == 4);
	assert(empty.contains("Lucy"));
	assert(empty.get(0, key, value) && key == "Fred" && value == 123);
	assert(empty.get(1, key, value) && key == "Ethel" && value == 456);
	assert(empty.get(2, key, value) && key == "Lucy" && value == 789);
	assert(empty.get(3, key, value) && key == "Ricky" && value == 321);
	assert(!empty.get(4, key, value));
	m2.update("Lucy", 654);
	assert(!combine(m1, m2, empty));
	assert(empty.size() == 3);
	assert(!empty.contains("Lucy"));
	assert(empty.get(0, key, value) && key == "Fred" && value == 123);
	assert(empty.get(1, key, value) && key == "Ethel" && value == 456);
	assert(empty.get(2, key, value) && key == "Ricky" && value == 321);
	assert(combine(m1, m1, empty));
	assert(empty.size() == m1.size());
	assert(!empty.contains("Ricky"));
	assert(empty.get(0, key, value) && key == "Fred" && value == 123);
	assert(empty.get(1, key, value) && key == "Ethel" && value == 456);
	assert(empty.get(2, key, value) && key == "Lucy" && value == 789);
	cout << "m2:" << endl;
	for (int i = 0; i < m2.size(); i++)
	{
		m2.get(i, key, value);
		cout << key << " " << value << endl;
	}
	cout << endl << "empty before:" << endl;
	for (int i = 0; i < empty.size(); i++)
	{
		empty.get(i, key, value);
		cout << key << " " << value << endl;
	}
	assert(!combine(m2, empty, empty));
	cout << endl << "empty after:" << endl;
	cout << empty.size() << endl;
	for (int i = 0; i < empty.size(); i++)
	{
		empty.get(i, key, value);
		cout << key << " " << value << endl;
	}
	assert(empty.size() == 3);
	assert(empty.get(0, key, value) && key == "Fred" && value == 123);
	assert(empty.get(1, key, value) && key == "Ethel" && value == 456);
	assert(empty.get(2, key, value) && key == "Ricky" && value == 321);
	assert(!empty.contains("Lucy"));
	// reset test cases to original
	Map cleared;
	m1 = m2 = cleared;
	m1.insertOrUpdate("Fred", 123);
	m1.insertOrUpdate("Ethel", 456);
	m1.insertOrUpdate("Lucy", 789);
	m2.insertOrUpdate("Lucy", 789);
	m2.insertOrUpdate("Ricky", 321);
	assert(combine(m1, m2, m1));
	assert(m1.size() == 4);
	assert(m1.get(0, key, value) && key == "Fred" && value == 123);
	assert(m1.get(1, key, value) && key == "Ethel" && value == 456);
	assert(m1.get(2, key, value) && key == "Lucy" && value == 789);
	assert(m1.get(3, key, value) && key == "Ricky" && value == 321);
	m1 = m2 = cleared;
	m1.insertOrUpdate("Fred", 123);
	m1.insertOrUpdate("Ethel", 456);
	m1.insertOrUpdate("Lucy", 789);
	m2.insertOrUpdate("Lucy", 654);
	m2.insertOrUpdate("Ricky", 321);
	assert(!combine(m1, m2, m1));
	assert(m1.size() == 3);
	assert(m1.get(0, key, value) && key == "Fred" && value == 123);
	assert(m1.get(1, key, value) && key == "Ethel" && value == 456);
	assert(m1.get(2, key, value) && key == "Ricky" && value == 321);
	Map getReassigned, reassigned;
	assert(getReassigned.empty() && reassigned.empty());
	reassign(getReassigned, reassigned);
	assert(getReassigned.empty() && reassigned.empty());
	getReassigned.insert("Annie", 25);
	getReassigned.insert("Bonnie", 14);
	getReassigned.insert("Tony", 31);
	getReassigned.insert("Sunny", 21);
	reassign(getReassigned, reassigned);
	assert(reassigned.size() == getReassigned.size());
	assert(reassigned.get(0, key, value) && key == "Annie" && value == 14);
	assert(reassigned.get(1, key, value) && key == "Bonnie" && value == 31);
	assert(reassigned.get(2, key, value) && key == "Tony" && value == 21);
	assert(reassigned.get(3, key, value) && key == "Sunny" && value == 25);
	getReassigned = cleared;
	getReassigned.insert("Annie", 4);
	reassign(getReassigned, reassigned);
	assert(reassigned.size() == 1);
	assert(reassigned.get(0, key, value) && key == "Annie" && value == 4);
	assert(!reassigned.get(-1, key, value));
	assert(!reassigned.get(reassigned.size(), key, value));
	assert(!reassigned.get(1, key, value));
	reassign(getReassigned, getReassigned);
	assert(getReassigned.size() == 1);
	assert(getReassigned.get(0, key, value) && key == "Annie" && value == 4);
	assert(!getReassigned.get(-1, key, value));
	assert(!getReassigned.get(reassigned.size(), key, value));
	assert(!getReassigned.get(1, key, value));
	getReassigned = cleared;
	getReassigned.insert("Annie", 25);
	getReassigned.insert("Bonnie", 14);
	getReassigned.insert("Tony", 31);
	getReassigned.insert("Sunny", 21);
	reassign(getReassigned, getReassigned);
	assert(getReassigned.size() == 4);
	assert(getReassigned.get(0, key, value) && key == "Annie" && value == 14);
	assert(getReassigned.get(1, key, value) && key == "Bonnie" && value == 31);
	assert(getReassigned.get(2, key, value) && key == "Tony" && value == 21);
	assert(getReassigned.get(3, key, value) && key == "Sunny" && value == 25);
	getReassigned = cleared;
	reassign(getReassigned, getReassigned);
	assert(getReassigned.empty());
}*/